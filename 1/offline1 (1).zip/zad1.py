from zad1testy import Node, runtests


def SortH(p,k):
    # tu prosze wpisac wlasna implementacje
    pass

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( SortH, all_tests = True )
