from zad5testy import runtests

def spacetravel( n, E, S, a, b ):
    # tu prosze wpisac wlasna implementacje
    return None

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( spacetravel, all_tests = False )