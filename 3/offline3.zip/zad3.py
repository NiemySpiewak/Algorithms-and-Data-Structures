from zad3testy import runtests

def dominance(P):
  # tu prosze wpisac wlasna implementacje
  return -1

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( dominance, all_tests = True )
