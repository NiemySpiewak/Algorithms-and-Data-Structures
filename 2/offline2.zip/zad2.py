from zad2testy import runtests

def ksum(T, k, p):
    # tu prosze wpisac wlasna implementacje
    return -1


# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( ksum, all_tests=True )
